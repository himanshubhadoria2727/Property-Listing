<?php

namespace Botble\Setting\Repositories\Eloquent;

use Botble\Setting\Repositories\Interfaces\SettingInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class SettingRepository extends RepositoriesAbstract implements SettingInterface
{
}
