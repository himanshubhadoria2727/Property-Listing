<x-core::form.textarea {{ $attributes }} />
